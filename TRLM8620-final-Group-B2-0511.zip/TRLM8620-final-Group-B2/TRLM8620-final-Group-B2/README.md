# TRLM8620-Final
This is the final project for TRLM8620. Students will clone this repo to create their own shopping website by switching the content, and localize the website.
